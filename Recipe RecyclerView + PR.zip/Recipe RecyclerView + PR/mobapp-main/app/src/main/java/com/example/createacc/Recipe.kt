package com.example.createacc.models

data class Recipe(
    val id: Int,
    val imageResId: Int,
    val title: String,
    val description: String
)
